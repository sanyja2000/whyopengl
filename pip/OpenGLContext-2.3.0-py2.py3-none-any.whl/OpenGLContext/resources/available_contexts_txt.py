# -*- coding: ISO-8859-1 -*-
"""Resource available_contexts_txt (from file available_contexts.txt)"""
# written by resourcepackage: (1, 0, 1)
source = 'available_contexts.txt'
package = 'OpenGLContext.resources'

import zlib
data = zlib.decompress((b'x\xda+\xa8LO\xccM\xe5\x0c\xa8t\x07R\\\xe5\x15\x9c\xe5\x15\x01\x95%\x19\xf9y\\\xe99\xa5%\x9c\xee>\xa1!\\%\xd9\x9c!\xd9\x99y%\xa9E\\\x00\x8fU\x10+'))
### end
