"""OpenGLContext "browser" components for wxPython
"""