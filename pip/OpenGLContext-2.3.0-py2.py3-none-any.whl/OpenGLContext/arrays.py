"""Abstraction point allowing OpenGLContext to be used with numpy or Numeric"""
from vrml.arrays import *